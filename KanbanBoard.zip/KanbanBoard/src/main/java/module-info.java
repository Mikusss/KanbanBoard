module com.example.kanbanboard {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;

    opens com.example.kanbanboard to javafx.fxml;
    exports com.example.kanbanboard;
}